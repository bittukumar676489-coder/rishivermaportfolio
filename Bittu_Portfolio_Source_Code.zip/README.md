# Bittu Kumar — Portfolio Website

A responsive dark portfolio built with Next.js, Framer Motion and Lenis smooth scrolling.

## Run locally
1. Install Node.js (LTS).
2. Open this folder in VS Code.
3. Run `npm install`
4. Run `npm run dev`
5. Open http://localhost:3000

## Deploy to Vercel through GitHub
1. Create a new GitHub repository.
2. Upload all files and folders from this project (not the ZIP file itself).
3. In Vercel choose **Add New → Project**, import the GitHub repository.
4. Framework preset: Next.js. Build command: `npm run build`.
5. Click Deploy.

The project uses `output: export`, so it can also be hosted as a static Next.js site.

## IMPORTANT: Personalise before sharing
Open `app/page.tsx` and replace:
- `your.email@example.com` with your real professional email.
- LinkedIn URL with your profile URL.
- GitHub URL with your GitHub profile URL.
- Review all portfolio statements and keep only work you have genuinely done.

The project examples are written as experience areas / representative work, not claims of named client deployments. Add real project details only when accurate.
