import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Bittu Kumar | Dynamics 365 BC Functional Consultant",
  description: "Portfolio of Bittu Kumar — Dynamics 365 Business Central, ERP, Export Documentation and Logistics Operations.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}