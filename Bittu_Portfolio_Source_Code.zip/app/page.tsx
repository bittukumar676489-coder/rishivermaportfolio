 "use client";

import { useEffect, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowUpRight, Boxes, BriefcaseBusiness, CheckCircle2, Code2, FileCheck2, Globe2, Layers3, Mail, Menu, PackageCheck, Send, ShieldCheck, Workflow, X, Zap } from "lucide-react";
import SmoothScroll from "./smooth-scroll";

const skills = [
  { icon: Workflow, title: "Dynamics 365 Business Central", text: "Functional workflows, configuration support, master data and ERP process understanding." },
  { icon: FileCheck2, title: "Export Documentation", text: "Commercial Invoice, Packing List, Shipping Bill, AWB, shipment coordination and document checks." },
  { icon: PackageCheck, title: "Logistics & Supply Chain", text: "Order processing, dispatch coordination, freight details, shipment tracking and delivery documentation." },
  { icon: ShieldCheck, title: "UAT & Testing", text: "Test scenarios, test cases, execution, defect logging, retesting and user sign-off support." },
  { icon: Boxes, title: "Inventory & Warehouse", text: "Item masters, UOM, stock movement, warehouse processes and inventory accuracy." },
  { icon: Layers3, title: "Business Process Mapping", text: "Requirement understanding, AS-IS / TO-BE flows, process documentation and user coordination." },
];

const projects = [
  { n: "01", tag: "ERP · FUNCTIONAL", title: "Business Central Workflow", desc: "Mapped business requirements into practical ERP workflows across sales, purchasing, inventory and finance touchpoints.", chips: ["D365 Business Central", "Sales Order", "Purchase Process"] },
  { n: "02", tag: "EXPORT · LOGISTICS", title: "Export Documentation Flow", desc: "Coordinated export order documentation and shipment readiness through invoice, packing list, AWB and dispatch checks.", chips: ["Commercial Invoice", "Packing List", "AWB / Shipping"] },
  { n: "03", tag: "QUALITY · UAT", title: "UAT & Process Validation", desc: "Prepared scenarios, validated expected results, recorded defects, retested fixes and supported business-user confirmation.", chips: ["Test Scenarios", "Bug Reporting", "Retesting"] },
];

const process = ["Understand requirement", "Map business process", "Configure / coordinate", "Prepare UAT scenarios", "Execute & log defects", "Validate and sign off"];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { scrollYProgress } = useScroll();
  const progress = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);
  useEffect(() => { document.documentElement.style.scrollBehavior = "smooth"; }, []);

  const closeMenu = () => setMenuOpen(false);
  return (
    <SmoothScroll>
      <motion.div className="scroll-progress" style={{ width: progress }} />
      <header className="nav">
        <a className="brand" href="#home" onClick={closeMenu}><span className="brand-mark">BK</span><span>BITTU<span className="muted">.WORKS</span></span></a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? "nav-links open" : "nav-links"}>
          {["About", "Expertise", "Work", "UAT Process", "Contact"].map((item) => <a key={item} href={`#${item.toLowerCase().replace(" ", "-")}`} onClick={closeMenu}>{item}</a>)}
          <a className="nav-cta" href="#contact" onClick={closeMenu}>Let&apos;s talk <ArrowUpRight size={15} /></a>
        </nav>
      </header>

      <main>
        <section className="hero section-wrap" id="home">
          <div className="hero-grid">
            <div className="hero-copy">
              <motion.div className="eyebrow" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7 }}><span className="pulse" /> ERP · EXPORT · LOGISTICS</motion.div>
              <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .8, delay: .1 }}>Turning business<br />processes into <span className="gradient-text">better systems.</span></motion.h1>
              <motion.p className="hero-sub" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .4 }}>I&apos;m Bittu Kumar — a Business Central ERP professional connecting functional workflows, export operations and UAT validation.</motion.p>
              <motion.div className="hero-actions" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .55 }}>
                <a className="btn primary" href="#work">Explore my work <ArrowUpRight size={17} /></a>
                <a className="btn secondary" href="#contact">Contact me <Mail size={16} /></a>
              </motion.div>
              <div className="hero-meta"><span><i /> Open to opportunities</span><span>Delhi NCR · India</span></div>
            </div>
            <motion.div className="hero-visual" initial={{ opacity: 0, scale: .88, rotateY: -12 }} animate={{ opacity: 1, scale: 1, rotateY: 0 }} transition={{ duration: 1, delay: .2 }}>
              <div className="orb orb-one" /><div className="orb orb-two" />
              <div className="visual-card">
                <div className="visual-top"><span className="window-dots"><i /><i /><i /></span><span>BUSINESS PROCESS / 001</span></div>
                <div className="visual-center"><div className="cube"><div className="cube-face front">BC</div><div className="cube-face side">ERP</div><div className="cube-face top">365</div></div><div className="visual-title">BUSINESS<br /><b>IN MOTION.</b></div></div>
                <div className="visual-bottom"><span>FUNCTIONAL CONSULTING</span><span className="visual-line" /><span>01 — 06</span></div>
              </div>
              <div className="float-chip chip-a"><span className="chip-icon"><CheckCircle2 size={15} /></span><span><b>UAT Ready</b><small>Test · Validate · Deliver</small></span></div>
              <div className="float-chip chip-b"><Globe2 size={17} /><span><b>Export & Logistics</b><small>Global operations</small></span></div>
              <div className="visual-caption">SYSTEMS THINKING <span>×</span> BUSINESS IMPACT</div>
            </motion.div>
          </div>
          <a className="scroll-hint" href="#about"><span>SCROLL TO EXPLORE</span><ArrowDown size={15} /></a>
        </section>

        <section className="intro-strip"><div className="strip-inner"><span>MICROSOFT DYNAMICS 365</span><b>✳</b><span>BUSINESS CENTRAL</span><b>✳</b><span>EXPORT OPERATIONS</span><b>✳</b><span>UAT & VALIDATION</span><b>✳</b><span>LOGISTICS</span></div></section>

        <section className="section section-wrap about" id="about">
          <div className="section-label"><span>01 / ABOUT ME</span><span className="label-line" /></div>
          <div className="about-grid">
            <h2>Bridging the gap between <span className="gradient-text">business needs</span> and technology.</h2>
            <div className="about-text"><p>I work across ERP business processes and export-logistics operations, with a practical understanding of how orders, inventory, documentation and dispatch connect.</p><p>My focus is on making workflows clear, keeping data accurate and helping users validate that systems work as expected — from requirement understanding to UAT.</p><div className="about-note"><Zap size={18} /><span>Practical process knowledge. Structured execution. Continuous improvement.</span></div></div>
          </div>
          <div className="stats-row"><div><strong>ERP</strong><span>Business Central</span></div><div><strong>UAT</strong><span>Testing & validation</span></div><div><strong>EXIM</strong><span>Export operations</span></div><div><strong>SCM</strong><span>Logistics & inventory</span></div></div>
        </section>

        <section className="section section-wrap expertise" id="expertise">
          <div className="section-label"><span>02 / WHAT I DO</span><span className="label-line" /></div>
          <div className="section-heading"><h2>Core <span className="gradient-text">expertise.</span></h2><p>Business-focused skills across ERP, documentation, operations and testing.</p></div>
          <div className="skill-grid">{skills.map((s, i) => { const Icon = s.icon; return <motion.article className="skill-card" key={s.title} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .2 }} transition={{ delay: i * .07 }}><div className="skill-icon"><Icon size={21} /></div><span className="card-index">0{i + 1}</span><h3>{s.title}</h3><p>{s.text}</p><div className="card-arrow"><ArrowUpRight size={17} /></div></motion.article>; })}</div>
        </section>

        <section className="section section-wrap work" id="work">
          <div className="section-label"><span>03 / SELECTED WORK</span><span className="label-line" /></div>
          <div className="section-heading"><h2>Where process meets <span className="gradient-text">execution.</span></h2><p>Representative work areas based on my ERP and export operations experience.</p></div>
          <div className="project-list">{projects.map((p) => <article className="project-row" key={p.n}><div className="project-number">{p.n}</div><div className="project-main"><span className="project-tag">{p.tag}</span><h3>{p.title}</h3><p>{p.desc}</p><div className="chips">{p.chips.map(c => <span key={c}>{c}</span>)}</div></div><div className="project-symbol"><ArrowUpRight size={23} /></div></article>)}</div>
        </section>

        <section className="uat-section" id="uat-process"><div className="section-wrap uat-inner">
          <div className="section-label"><span>04 / UAT WORKFLOW</span><span className="label-line" /></div>
          <div className="uat-heading"><div><h2>Test with purpose.<br /><span className="gradient-text">Deliver with confidence.</span></h2><p>A structured approach to validating ERP functionality against real business requirements.</p></div><div className="uat-stamp"><ShieldCheck size={27} /><span>QUALITY<br />BUILT IN</span></div></div>
          <div className="process-line">{process.map((p, i) => <div className="process-step" key={p}><div className="step-dot">{String(i + 1).padStart(2, "0")}</div><h4>{p}</h4>{i !== process.length - 1 && <div className="step-connector" />}</div>)}</div>
          <div className="uat-bottom"><span>FROM REQUIREMENT TO USER SIGN-OFF</span><span>STRUCTURED · TRACEABLE · BUSINESS-LED</span></div>
        </div></section>

        <section className="section section-wrap contact" id="contact">
          <div className="section-label"><span>05 / GET IN TOUCH</span><span className="label-line" /></div>
          <div className="contact-panel"><div><span className="project-tag">HAVE A ROLE OR PROJECT IN MIND?</span><h2>Let&apos;s make work<br /><span className="gradient-text">flow better.</span></h2><p>Open to opportunities in Business Central ERP, functional consulting, export operations and logistics.</p></div><div className="contact-links"><a href="mailto:your.email@example.com"><Mail size={18} /><span><small>EMAIL</small>your.email@example.com</span><ArrowUpRight size={17} /></a><a href="https://www.linkedin.com/" target="_blank" rel="noreferrer"><BriefcaseBusiness size={18} /><span><small>LINKEDIN</small>Connect professionally</span><ArrowUpRight size={17} /></a><a href="https://github.com/" target="_blank" rel="noreferrer"><Code2 size={18} /><span><small>GITHUB</small>View profile</span><ArrowUpRight size={17} /></a></div></div>
          <footer><a className="brand" href="#home"><span className="brand-mark">BK</span><span>BITTU<span className="muted">.WORKS</span></span></a><span>© {new Date().getFullYear()} BITTU KUMAR. BUILT WITH PURPOSE.</span><a href="#home">BACK TO TOP ↑</a></footer>
        </section>
      </main>
    </SmoothScroll>
  );
}